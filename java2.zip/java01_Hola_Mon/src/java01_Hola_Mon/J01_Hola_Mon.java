package java01_Hola_Mon;

public class J01_Hola_Mon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hola Mon");
	}

}
